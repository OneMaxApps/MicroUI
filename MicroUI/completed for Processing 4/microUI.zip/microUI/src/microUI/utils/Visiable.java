package microUI.utils;

public interface Visiable {}