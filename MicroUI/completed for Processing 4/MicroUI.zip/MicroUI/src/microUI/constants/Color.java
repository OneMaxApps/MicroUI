package microUI.constants;

public class Color {
public final static int WHITE = 0xFFFFFFFF;
public final static int BLACK = 0xFF000000;
public final static int GRAY = 0xFF888888;
public final static int RED = 0xFFFF0000;
public final static int GREEN = 0xFF00FF00;
public final static int BLUE = 0xFF0000FF;
public final static int YELLOW = 0xFFFFFF00;
public final static int SKY = 0xFF00FFFF;
public final static int PINK = 0xFFFF00FF;
public final static int TRANSPARENT = 0x00FFFFFF;
}